# -*- coding: utf-8 -*-
"""
Contiene funciones para simular el crecimiento de un pez en una piscifactoría

@author: TO DO
@date:   TO DO
"""

from typing import List

import random
import math

import matplotlib.pyplot as plt

# TO DO: Crear constantes para una lubina

# Coeficiente de crecimiento térmico, en gramos**(1/3)/(dia*ºC)

# factor de crecimiento en gr**(1/3)

# peso inicial (p0), gr


def get_peso(sum_temp: float)-> float:
    """
    Retorna el peso del pez

    Args:
        sum_temp: la suma de las temperaturas medias en los días de crecimiento
    Returns:
        el peso del pez, en gr
    """

    return math.nan # TO DO: reemplazar por la expresión apropiada


def temp_eficaz(temp_dia: float)-> float:
    """
    Retorna la temperatura eficaz (ºC) usada para el cálculo del crecimiento,
    dada la temperatura real en un día concreto

    Args:
        temp_dia: la temperatura media del día en grados centígrados
    Returns:
        la temperatura eficaz para el crecimiento, en grados centígrados;
        si el pez se muere, retorna nan
    """

    if temp_dia < 10:
        # la eficaz es cero (por debajo de 10º el pez no crece)
        return 0.0
    if temp_dia > 30:
        # la eficaz es nan (el pez se muere por demasiado calor)
        return math.nan
    # en otros casos, la eficaz es temp_dia-10
    return temp_dia-10


def temp_simulada(dias: int)-> float:
    """
    Obtiene la temperatura simulada, en ºC

    En los primeros 100 dias se simula un crecimiento inicial a temperatura
    constante (con calentadores en invierno) y luego a temperatura aleatoria
    en verano

    Args:
        dias: número de días de crecimiento
    Returns:
        la temperatura simulada para el dia indicado
    """
    if dias < 100:
        # invierno
        return 17.0
    # verano
    return random.uniform(17.0, 27.0)


def anota_datos(dias: int, peso: float,
                list_dias: List[int], list_pesos: List[float]):
    """
    Añade a las listas de dias y pesos los datos dias y peso

    Args:
        dias: El número de días de crecimiento
        peso: el peso actual del pez
        list_dias: la lista de los días
        list_pesos: la lista de los pesos
    """
    list_dias.append(dias)
    list_pesos.append(peso)


def muestra_grafica(list_dias: List[int], list_pesos: List[float]):
    """
    Muestra la gráfica de crecimiento del pez

    Args:
        list_dias: la lista de los días
        list_pesos: la lista de los pesos
    """
    plt.plot(list_dias, list_pesos)
    plt.ylabel('Peso (gr)')
    plt.xlabel('Dias')
    plt.title('Crecimiento de un pez en una piscifactoría')
    plt.grid(True)
    plt.show()


def main():
    """
    TO DO: Añadir el comentario de documentación apropiado
    """

    # creamos dos listas para los dias y los pesos del pez
    list_dias: List[int] = []
    list_pesos: List[float] = []

    # TO DO: Crear las variables pedidas
    dias: int = 0

    # Bucle que se repite durante 270 dias
    while dias <= 270:
        # TO DO: Reemplazar la instruccion pass por las instrucc. solicitadas
        pass
    # fin bucle while

    # TO DO: Mostrar la gráfica
